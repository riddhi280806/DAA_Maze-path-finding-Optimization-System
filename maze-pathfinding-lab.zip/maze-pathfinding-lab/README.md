# Maze Path-Finding Lab

DAA mini project: BFS, DFS, Dijkstra's Algorithm and A* on a grid maze.

## Run locally
Open `index.html` in any browser. No install, no libraries.

## Deploy
Upload this folder to Vercel or Netlify (drag and drop), or push it to GitHub and enable GitHub Pages.

## Features
- Maze layouts: one route, with loops, random obstacles, empty; mud cells (cost 5)
- Draw walls, move start and end, step-by-step animation
- "Compare all 4": path length, cost, cells explored, time, max frontier, optimal or not
- Complexity table and pseudocode

## Files
- `index.html`: the whole app (HTML + CSS + JavaScript)
- `docs/Maze_PathFinding_DAA.pptx`: presentation
